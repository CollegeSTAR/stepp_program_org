﻿var RESOURCES = {
    "menuToggleOpened": "Close",
    "menuToggleClosed": "Open"
}